package com.SRTP.strplocation.GnssCalculator;

import android.content.Context;
import android.location.GnssStatus;

import com.SRTP.strplocation.Utils.FileUtil;

import java.util.ArrayList;

import static java.lang.Math.abs;
import static java.lang.Math.atan;
import static java.lang.Math.atan2;
import static java.lang.Math.cos;
import static java.lang.Math.pow;
import static java.lang.Math.sin;
import static java.lang.Math.sqrt;
import static java.lang.Math.tan;

public class SinglePositioning {

    private static final double C_light=299792458.458;
    private static final double  PI=3.14159265359;
    private static int n=0;

    public static boolean Can_POS(int satNum,ArrayList<Sat> sats){
        int legalSat=0;
        for (int i = 0; i < sats.size(); i++) {
            Sat sat = sats.get(i);
            if (sat.equals(Sat.SatType.BDS,5))continue;
            legalSat++;
        }
        return legalSat>5;
    }

    public static void Get_SPP_POS(Epoch epoch, CMatrix XYZ)
    {

        boolean hasGPS = false;
        boolean hasBDS = false;

        //存储BL矩阵信息，不超过40颗卫星
        CMatrix BL=new CMatrix(40, 5);

        int sat_index = 0;

        for (int i = 0; i < epoch.sat_num; i++)
        {

            Sat tempSat =epoch.sat.get(i);
            //补齐矩阵最后一列
            if (tempSat.sattype == Sat.SatType.GPS){
                hasGPS=true;
                BL.p[sat_index][4]=1.0;
            }
            if (tempSat.sattype == Sat.SatType.BDS){
                hasBDS=true;
                BL.p[sat_index][4]=2.0;
            }

            //计算卫星到基站距离
            double Length = CalculateHeightAngle(XYZ, BL, sat_index, tempSat);

            //误差计算
            double error_left = CalculateErrorLeft(XYZ, tempSat, Length,0);

            BL.p[sat_index][3] = error_left;

            sat_index++;
        }

        //大于5颗表示可以定位
        if (sat_index > 5) {
            //定义B矩阵，存储高度角余弦值
            int B_col;
            if (hasBDS && hasGPS) B_col = 5;
            else B_col = 4;
            CMatrix B = new CMatrix(sat_index, B_col);
            //定义L矩阵,存储残差
            CMatrix L = new CMatrix(sat_index, 1);
            //定义Delta XYZ矩阵,存储定位迭代增量
            CMatrix Delta_XYZ;

            for (int i = 0; i < sat_index; i++) {
                B.p[i][0] = BL.p[i][0];
                B.p[i][1] = BL.p[i][1];
                B.p[i][2] = BL.p[i][2];

                L.p[i][0] = BL.p[i][3];

                //补齐钟差参数列，补1
                B.p[i][3] = 1;
                if (hasBDS && hasGPS) B.p[i][4] = 1;
            }
            //最小二乘法求解delta xyz矩阵
            Delta_XYZ = ((B.T()).Multiple(B)).InvertGaussJordan().Multiple(B.T()).Multiple(L);

            XYZ.p[0][0] += Delta_XYZ.p[0][0];
            XYZ.p[1][0] += Delta_XYZ.p[1][0];
            XYZ.p[2][0] += Delta_XYZ.p[2][0];
        }
    }

    private static double CalculateErrorLeft(CMatrix XYZ, Sat tempSat, double length,double error_tropDelay) {
        double error_satClock = tempSat.Sat_clock * C_light;
        double error_relativity = tempSat.xdl_t;
        double we = 7.2921151467e-5;
        if(tempSat.sattype== Sat.SatType.BDS) we=7.292115e-5;
        tempSat.Sagnac = we * (tempSat.POS_X * XYZ.p[1][0] - tempSat.POS_Y * XYZ.p[0][0]) / C_light;
        double error_sagnac = tempSat.Sagnac;

        //总误差
        double total_error = -error_satClock - error_relativity + error_sagnac + error_tropDelay;

        //残余误差
        return -(length - tempSat.pseudo + total_error);
    }

    private static double CalculateHeightAngle(CMatrix XYZ, CMatrix BL, int sat_index, Sat tempSat) {
        double Length = Math.sqrt(Math.pow(tempSat.POS_X - XYZ.p[0][0], 2) + Math.pow(tempSat.POS_Y - XYZ.p[1][0], 2) + Math.pow(tempSat.POS_Z - XYZ.p[2][0], 2));

        double CosX = (tempSat.POS_X - XYZ.p[0][0]) / Length;
        double CosY = (tempSat.POS_Y - XYZ.p[1][0]) / Length;
        double CosZ = (tempSat.POS_Z - XYZ.p[2][0]) / Length;

        BL.p[sat_index][0] = -CosX;
        BL.p[sat_index][1] = -CosY;
        BL.p[sat_index][2] = -CosZ;
        return Length;
    }

    //函数功能：初步单点定位功能（考虑高度角定权）
    public static void Get_SPP_POS_Ele(Epoch epoch, CMatrix XYZ)
    {
        boolean hasGPS = false;
        boolean hasBDS = false;

        //存储BL矩阵信息，不超过40颗卫星
        CMatrix BL=new CMatrix(40, 6);

        int sat_index = 0;

        for (int i = 0; i < epoch.sat_num; i++)
        {
            Sat tempSat =epoch.sat.get(i);
            if (tempSat.E < 15.0)continue;
            //补齐矩阵最后一列
            if (tempSat.sattype == Sat.SatType.GPS){
                hasGPS=true;
                BL.p[sat_index][4]=1.0;
            }
            if (tempSat.sattype == Sat.SatType.BDS){
                hasBDS=true;
                BL.p[sat_index][4]=2.0;
            }

            //计算卫星到基站距离
            double Length = CalculateHeightAngle(XYZ, BL, sat_index, tempSat);

            //误差计算
            double error_left = CalculateErrorLeft(XYZ, tempSat, Length,tempSat.Trop_Delay);

            BL.p[sat_index][3] = error_left;

            //存入高度角
            BL.p[sat_index][5]=tempSat.E;

            sat_index++;
        }

        //大于5颗表示可以定位
        if (sat_index > 5) {
            //定义B矩阵，存储高度角余弦值
            int B_col;
            if (hasBDS && hasGPS) B_col = 5;
            else B_col = 4;
            CMatrix B = new CMatrix(sat_index, B_col);
            //定义L矩阵,存储残差
            CMatrix L = new CMatrix(sat_index, 1);
            //定义R矩阵,为对角阵
            CMatrix R=new CMatrix(sat_index,sat_index);
            //定义Delta XYZ矩阵,存储定位迭代增量
            CMatrix Delta_XYZ;

            for (int i = 0; i < sat_index; i++) {
                B.p[i][0] = BL.p[i][0];
                B.p[i][1] = BL.p[i][1];
                B.p[i][2] = BL.p[i][2];

                L.p[i][0] = BL.p[i][3];

                double elp = Math.pow(Math.sin(Math.toRadians(BL.p[i][5])),2);
                R.p[i][i] = 0.09 + 0.09 / elp;

                //补齐钟差参数列，补1
                B.p[i][3] = 1;
                if (hasBDS && hasGPS) B.p[i][4] = 1;
            }
            //最小二乘法求解delta xyz矩阵
            CMatrix P = R.InvertGaussJordan();
            Delta_XYZ = ((B.T()).Multiple(B)).InvertGaussJordan().Multiple( B.T() ).Multiple( L );


            XYZ.p[0][0] += Delta_XYZ.p[0][0];
            XYZ.p[1][0] += Delta_XYZ.p[1][0];
            XYZ.p[2][0] += Delta_XYZ.p[2][0];
        }

    }
//传入的MessageRaw为特定GPSTime的一系列卫星的星历文件,GnssData为当前GPSTime的手机和基站共同观测到的卫星数据（包括伪距）
    private static Epoch tempEpoch;
    private static Context context;

    public static void setContext(Context context) {
        SinglePositioning.context = context;
    }

    public static double[] Position_Calculator(ArrayList<NavigationMessageRaw> navigationMessageRaws, ArrayList<SatSentMsg>satSentMsgs, double gpstime, int sat_num)
    {
        //存储GPS和BDS观测数据类型：BDS-2与BDS-3一致
        double[] XYZ = { 0,0,0 };

        //初始化概率坐标
        ReceiverInfo receiverPOS=new ReceiverInfo();

        //文件头概率坐标
        XYZ[0] = receiverPOS.APP_X;
        XYZ[1] = receiverPOS.APP_Y;
        XYZ[2] = receiverPOS.APP_Z;

        receiverPOS.LEAPSEC = 1;

        //迭代初值
        double init_X = 0;
        double init_Y = 0;
        double init_Z = 0;

        //初始化当前历元
        tempEpoch=new Epoch();
        tempEpoch.GPSTIME = gpstime;
        tempEpoch.sat_num = sat_num;

        StringBuilder logger=new StringBuilder("======================新历元======================\n\n");
        FileUtil.table_writer(logger,"%-22s","X","Y","Z");
        //将卫星存入当前历元
        for (int k = 0; k<tempEpoch.sat_num; k++)
        {
            Sat tempsat=new Sat();
            SatSentMsg currentSatMsg=satSentMsgs.get(k);
            for(int j=0;j<navigationMessageRaws.size();j++)
            {
                NavigationMessageRaw currentNavMsg=navigationMessageRaws.get(j);
                if (currentSatMsg.getPRN()==currentNavMsg.PRN) {
                    tempsat.pseudo = currentSatMsg.getPseudorange()+currentNavMsg.PRC;
                    tempsat.PRN=currentNavMsg.PRN;
                    tempsat.sattype=Sat.getSatType(currentSatMsg.getSVType());

                    double SpreadTime = tempsat.pseudo / C_light;
                    //补全tempSat[posX,posY,posZ,sat_clock,xdl,sagnac]
                    Calc_Eph_GCEJ(tempEpoch.GPSTIME, SpreadTime, tempsat, XYZ, navigationMessageRaws.get(k));
                    FileUtil.table_writer(logger,"%-18s",
                            String.valueOf(tempsat.POS_X),
                            String.valueOf(tempsat.POS_Y),
                            String.valueOf(tempsat.POS_Z));
                    //将卫星存入当前历元
                    tempEpoch.sat.add(tempsat);
                    break;
                }
            }
        }
        if (context!=null)FileUtil.WriteTXT(context.getExternalFilesDir(null)+"/SatPos.txt",logger.toString(),true);
        //初始历元进行伪距单点定位获得概略坐标，更新XYZ:

        //用于暂存上一次的计算值
        double LastX;
        double LastY;
        double LastZ;

        //建立一个存储xyz坐标的3维向量
        CMatrix Pos=new CMatrix(3, 1);

        //从第二个历元开始，不用第一次迭代的结果
            Pos.p[0][0] = init_X;
            Pos.p[1][0] = init_Y;
            Pos.p[2][0] = init_Z;

            LastX = Pos.p[0][0];
            LastY = Pos.p[1][0];
            LastZ = Pos.p[2][0];

        //判断该历元是否满足SPP条件（获取POS_IF）
        boolean canDoPOS = Can_POS(tempEpoch.sat_num,tempEpoch.sat);

        if (Math.abs(LastX) < 1.0 && Math.abs(LastY) < 1.0 && Math.abs(LastZ) < 1.0 && canDoPOS)
        {
            //进行第一次单点定位，求粗略坐标
            do
            {
                LastX = Pos.p[0][0];
                LastY = Pos.p[1][0];
                LastZ = Pos.p[2][0];

                Get_SPP_POS(tempEpoch, Pos);

            } while (Math.abs(LastX - Pos.p[0][0]) >= 0.1 || Math.abs(LastY - Pos.p[1][0]) >= 0.1 || Math.abs(LastZ - Pos.p[2][0]) >= 0.1);
        }

        //表示无法进行单点定位，也就无法获得初始坐标，暂时标为不可用
        if (!canDoPOS)
        {
            //将初始坐标置为0
            Pos.p[0][0] = 0;
            Pos.p[1][0] = 0;
            Pos.p[2][0] = 0;

            tempEpoch.ZHD = 0;

            //用新的坐标更新高度角、方位角、对流层等信息
            for (int k = 0; k < tempEpoch.sat_num; k++)
            {
                //全部置0
                Sat tempsat;
                tempsat = tempEpoch.sat.get(k);
                tempsat.E = 0;
                tempsat.A = 0;
                tempsat.Trop_Delay = 0;
                tempsat.Trop_Map = 0;
                tempsat.Sagnac = 0;
                tempEpoch.sat.set(k,tempsat);
            }
        }

        else
        {
            //更新经纬度,放入第一次粗略计算坐标
            XYZ[0] = LastX;
            XYZ[1] = LastY;
            XYZ[2] = LastZ;

            double []BLH = new double [3];
            OnXYZtoBLH(LastX, LastY, LastZ, BLH);

            receiverPOS.B = BLH[0];
            receiverPOS.L = BLH[1];
            receiverPOS.DH = BLH[2];
            CMatrix HH=new CMatrix(3, 3);

            HH.p[0][0] = -Math.sin(receiverPOS.B)*Math.cos(receiverPOS.L);
            HH.p[0][1] = -Math.sin(receiverPOS.B)*Math.sin(receiverPOS.L);
            HH.p[0][2] = Math.cos(receiverPOS.B);
            HH.p[1][0] = -Math.sin(receiverPOS.L);
            HH.p[1][1] = Math.cos(receiverPOS.L);
            HH.p[1][2] = 0;
            HH.p[2][0] =Math.cos(receiverPOS.B)*Math.cos(receiverPOS.L);
            HH.p[2][1] = Math.cos(receiverPOS.B)*Math.sin(receiverPOS.L);
            HH.p[2][2] = Math.sin(receiverPOS.B);

            //考虑对流层再进行一次坐标解算,添加了高度角,方位角,对流层改正,更新了sagnac改正
            for (int k = 0; k < tempEpoch.sat_num; k++)
            {
                Sat tempsat;
                tempsat = tempEpoch.sat.get(k);

                //计算高度角和方位角
                CalSatEA(HH, XYZ, tempsat);

                //计算对流层改正
                tempsat.Trop_Delay= TroposphereModel.tropomodel(BLH,tempsat.E*PI/180.0,0.5);
                tempsat.Trop_Map=0;

                //计算Sagnac效应改正
                double we = 7.2921151467e-5;
                tempsat.Sagnac = we * (tempsat.POS_X * XYZ[1] - tempsat.POS_Y * XYZ[0]) / C_light;
                tempEpoch.sat.set(k,tempsat);
            }

            //考虑高度角方位角，重新计算坐标
            do
            {
                LastX = Pos.p[0][0];
                LastY = Pos.p[1][0];
                LastZ = Pos.p[2][0];

                Get_SPP_POS_Ele(tempEpoch, Pos);

            } while (Math.abs(LastX - Pos.p[0][0]) >= 0.1 || Math.abs(LastY - Pos.p[1][0]) >= 0.1 || Math.abs(LastZ - Pos.p[2][0]) >= 0.1);

            XYZ[0] = Pos.p[0][0];
            XYZ[1] = Pos.p[1][0];
            XYZ[2] = Pos.p[2][0];

            //用新的坐标更新高度角、方位角、对流层等信息
            for (int k = 0; k < tempEpoch.sat_num; k++)
            {
                Sat tempsat;
                tempsat = tempEpoch.sat.get(k);
                //计算高度角和方位角
                CalSatEA(HH, XYZ, tempsat);

                //计算对流层
                tempsat.Trop_Delay= TroposphereModel.tropomodel(BLH,tempsat.E*PI/180.0,0.5);
                tempsat.Trop_Map=0;
                //计算Sagnac效应改正
                double we = 7.2921151467e-5;
                tempsat.Sagnac = we * (tempsat.POS_X * XYZ[1] - tempsat.POS_Y * XYZ[0]) / C_light;
                tempEpoch.sat.set(k,tempsat);
            }
        }
        LastX = Pos.p[0][0];
        LastY = Pos.p[1][0];
        LastZ = Pos.p[2][0];
        double []final_BLH = new double [3];
        OnXYZtoBLH(LastX,LastY,LastZ,final_BLH);
        n++;
        return final_BLH;
    }

    private static void OnXYZtoBLH(double X, double Y, double Z, double[] BLH)
    {
        double a = 6378137.000, e = 0.00669437999014132;
        double R = sqrt(X*X + Y*Y);
        double B0 = atan2(Z, R);
        double N;
        double B, L, H;

        L = atan2(Y, X);

        while (true)
        {
            N = a / sqrt(1 - e * sin(B0) * sin(B0));
            B = atan2(Z + N * e * sin(B0), R);
            H = R / cos(B) - N;

            if (abs(B - B0) < 1e-12)
                break;
            B0 = B;
        }

        BLH[0] = B/PI*180;
        BLH[1] = L/PI*180;
        BLH[2] = H/PI*180;

    }
    //函数功能：获取卫星的高度角和方位角
    private static void CalSatEA(CMatrix HH, double[] StaXYZ, Sat sat)
    {
        if (HH.Row != 3 || HH.Col != 3) {
            throw new IllegalArgumentException("输入矩阵行列必须为3");
        }

        //计算高度角和方位角
        CMatrix DeltXYZ;
        CMatrix Sta2Sat;
        Sta2Sat=new CMatrix(3, 1);

        Sta2Sat.setP_singleNum(0,0,sat.POS_X - StaXYZ[0]);
        Sta2Sat.setP_singleNum(1,0,sat.POS_Y - StaXYZ[1]);
        Sta2Sat.setP_singleNum(2,0,sat.POS_Z - StaXYZ[2]);

        DeltXYZ = HH.Multiple(Sta2Sat) ;
        sat.A = atan2(DeltXYZ.GetNum(1,0), DeltXYZ.GetNum(0,0));
        sat.A = sat.A * 180 / PI;

        if (sat.A < 0)
        {
            sat.A = sat.A + 360;
        }

        sat.E = atan(DeltXYZ.GetNum(2,0) / sqrt(pow(DeltXYZ.GetNum(0,0), 2) + pow(DeltXYZ.GetNum(1,0), 2)));
        sat.E = sat.E * 180 / PI;
    }
    //函数功能：进行接收机天线改正
//    void AntOffsetCorrect(Obs_epoch tempData, double []PCO1, double []PCO2)
//    {
//        double c = 299792458.458;
//        double off_L1, off_L2;
//        double lambda_l1=0, lambda_l2=0;
//
//        double f_gps1 = 154 * 10.23E6;
//        double f_gps2 = 120 * 10.23E6;
//
//        double f_geo1 = 1575.42E6;
//        double f_geo2 = 1176.45E6;
//
//
//        for (int i = 0; i < tempData.sat.size(); i++)
//        {
//            if (tempData.sat.get(i).judge_use == 2)
//                continue;
//
//            if (tempData.sat.get(i).sattype.equals("G"))
//            {
//                lambda_l1 = c / f_gps1;
//                lambda_l2 = c / f_gps2;
//            }
//
//            if (tempData.sat.get(i).sattype.equals("E"))
//            {
//                lambda_l1 = c / f_geo1;
//                lambda_l2 = c / f_geo2;
//            }
//
//            double elev = tempData.sat.get(i).E / 180.0 * PI;
//            double A = tempData.sat.get(i).A / 180.0 * PI;
//
//            //表明未能获得概略坐标
//            if (elev < 0.5 && A < 0.5)
//            {
//                tempData.sat.get(i).OffsetL1 = 0;
//                tempData.sat.get(i).OffsetL2 = 0;
//                continue;
//            }
//
//            double cosel = cos(elev);
//            double sinel = sin(elev);
//            double cosaz = cos(A);
//            double sinaz = sin(A);
//
//            off_L1 = (PCO1[0] * cosel * cosaz + PCO1[1] * cosel * sinaz + PCO1[2] * sinel) / 1000.0;
//            off_L2 = (PCO2[0] * cosel * cosaz + PCO2[1] * cosel * sinaz + PCO2[2] * sinel) / 1000.0;
//
//            tempData.sat.get(i).OffsetL1 = off_L1 / lambda_l1;
//            tempData.sat.get(i).OffsetL2 = off_L2 / lambda_l2;
//        }
//    }

    //函数功能：根据匹配到的星历进行单个卫星位置计算（GPS和BDS）

    /**
     *
     * @param GPSTIME
     * @param rclk 传播时间
     * @param sat 当前卫星
     * @param XYZ 接收机坐标,用于计算sagnac效应
     * @param EpochNG 当前卫星星历
     */
    private static void Calc_Eph_GCEJ(double GPSTIME, double rclk, Sat sat, double[] XYZ, NavigationMessageRaw EpochNG)
    {
        double we = 7.2921151467e-5;
        double GM = 3.9860050e14;

        double n0, n, tk, Mk, ek1, ek2, Ek, Vk, fk;
        double deltau, deltar, deltai, uk, rk, ik, xk, yk, Lk;
        EpochNG.GPSTIME=JudgeEphemeris.GetGPSTime(EpochNG);
        n0 = sqrt(GM) / pow(EpochNG.sqrtA, 3);
        n = n0 + EpochNG.delta_n;

        tk = GPSTIME - EpochNG.GPSTIME;

        if (tk > 302400) tk -= 604800.0;
        else if (tk < -302400) tk += 604800.0;

        sat.Sat_clock = EpochNG.a0 + EpochNG.a1 * tk + EpochNG.a2 * pow(tk, 2);
        //sat.TGD = EpochNG.TGD * C_light;

        tk = tk - sat.Sat_clock - rclk;

        Mk = EpochNG.M0 + n*tk;

        ek1 = Mk;
        do
        {
            ek2 = Mk + EpochNG.e*sin(ek1);
            if (abs(ek2 - ek1) <= 1.0e-13)  break;
            ek1 = ek2;
        } while (true);

        Ek = ek1;
        Vk = 2 * atan(sqrt((1.0 + EpochNG.e) / (1.0 - EpochNG.e))*tan(Ek / 2));
        fk = Vk + EpochNG.w;

        deltau = EpochNG.Cuc * cos(2.0*fk) + EpochNG.Cus * sin(2.0*fk);
        deltar = EpochNG.Crc * cos(2.0*fk) + EpochNG.Crs * sin(2.0*fk);
        deltai = EpochNG.Cic * cos(2.0*fk) + EpochNG.Cis * sin(2.0*fk);

        uk = fk + deltau;
        rk = EpochNG.sqrtA * EpochNG.sqrtA * (1.0 - EpochNG.e*cos(Ek)) + deltar;
        ik = EpochNG.i0 + deltai + EpochNG.i_DOT * tk;

        xk = rk * cos(uk);
        yk = rk * sin(uk);

        Lk = EpochNG.OMEGA + (EpochNG.OMEGA_DOT - we)*tk - we* EpochNG.TOE;
        sat.POS_X = xk * cos(Lk) - yk * cos(ik) * sin(Lk);
        sat.POS_Y = xk * sin(Lk) + yk * cos(ik) * cos(Lk);
        sat.POS_Z = yk * sin(ik);

        sat.xdl_t = -2 * sqrt(GM) * EpochNG.e * EpochNG.sqrtA * sin(Ek) / C_light;

        //计算地球自转效应:粗略解算
        sat.Sagnac = we * (sat.POS_X * XYZ[1] - sat.POS_Y * XYZ[0]) / C_light;
    }
}
