package com.SRTP.strplocation.GnssRawData;

import android.location.GnssMeasurement;
import android.location.GnssMeasurementsEvent;
import android.location.GnssNavigationMessage;
import android.location.GnssStatus;
import android.location.Location;
import android.os.Bundle;

import com.SRTP.strplocation.GnssCalculator.SatSentMsg;
import com.SRTP.strplocation.Utils.FileUtil;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class txtLogger implements GnssListener {
    private File Dir;

    public void setDir(File dir) {
        Dir = dir;
    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @Override
    public void onLocationChanged(Location location) {

    }

    @Override
    public void onLocationStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onGnssMeasurementsReceived(GnssMeasurementsEvent event) {
        StringBuilder txt_writer=new StringBuilder("======================新历元======================\n\n");
        //writer(txt_writer,"GPS周内秒", String.valueOf(SatSentMsg.getGPSTime(event.getClock())));
        FileUtil.table_writer(txt_writer,"%-12s","GPS_TIME","PRN","伪距");
        for (GnssMeasurement measurement : event.getMeasurements()) {
            if (measurement.getConstellationType()==GnssStatus.CONSTELLATION_GPS) {
                SatSentMsg data=new SatSentMsg(measurement,event.getClock());
//                writer(txt_writer, "prn", String.valueOf(measurement.getSvid()));
//                writer(txt_writer,"伪距", String.valueOf(data.getPseudorange()));
//                writer(txt_writer, "伪距速率", String.valueOf(measurement.getPseudorangeRateMetersPerSecond()));
//                txt_writer.append('\n');
                FileUtil.table_writer(txt_writer,"%-12s",
                        String.valueOf(Math.round(SatSentMsg.getGPSTime(event.getClock()))),
                        String.valueOf(measurement.getSvid()),
                        String.valueOf(data.getPseudorange()));
            }
        }
        FileUtil.WriteTXT(Dir+"/PseuData"+".txt",txt_writer.toString(),true);
        //WriteTXT(Dir,txt_writer.toString());
    }

    @Override
    public void onGnssMeasurementsStatusChanged(int status) {

    }

    @Override
    public void onGnssNavigationMessageReceived(GnssNavigationMessage event) {

    }

    @Override
    public void onGnssNavigationMessageStatusChanged(int status) {

    }

    @Override
    public void onGnssStatusChanged(GnssStatus gnssStatus) {

    }

    @Override
    public void onListenerRegistration(String listener, boolean result) {

    }

    @Override
    public void onNmeaReceived(long l, String s) {

    }

    @Override
    public void onTTFFReceived(long l) {

    }

    private void writer(StringBuilder builder,String tag,String pama){
        final String format = "   %-4s = %s\n";
        builder.append(
                String.format(
                        format, tag, pama));
        builder.append('\n');
    }
    public static void table_writer(StringBuilder builder,String format,String ...columns){
        for (String col:columns) {
            builder.append(String.format(format,col));
            builder.append("\t");
        }
        builder.append("\n");
    }
    private static void WriteTXT(File Dir, String content){
        File mk_txt=new File(Dir+"/PseuData"+".txt" );
        BufferedWriter out = null;
        try {
                out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(mk_txt, true)));
                out.write(content+"\r\n");
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    assert out != null;
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

    }
}
